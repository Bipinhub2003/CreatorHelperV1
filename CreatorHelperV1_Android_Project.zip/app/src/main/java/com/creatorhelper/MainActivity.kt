package com.creatorhelper

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

data class Tool(val title: String, val emoji: String, val description: String)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { CreatorHelperApp() }
    }
}

@Composable
fun CreatorHelperApp() {
    var selected by remember { mutableStateOf("Home") }
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Color(0xFFFFC107),
            secondary = Color(0xFFFF5252),
            background = Color(0xFF090D18),
            surface = Color(0xFF121827)
        )
    ) {
        Scaffold(
            containerColor = MaterialTheme.colorScheme.background,
            bottomBar = {
                NavigationBar(containerColor = Color(0xFF101624)) {
                    listOf(
                        "Home" to Icons.Default.Home,
                        "Templates" to Icons.Default.Palette,
                        "Premium" to Icons.Default.Star,
                        "Profile" to Icons.Default.Person
                    ).forEach { (name, icon) ->
                        NavigationBarItem(
                            selected = selected == name,
                            onClick = { selected = name },
                            icon = { Icon(icon, null) },
                            label = { Text(name) }
                        )
                    }
                }
            }
        ) { padding ->
            when (selected) {
                "Home" -> HomeScreen(padding) { selected = it }
                "Templates" -> TemplatesScreen(padding)
                "Premium" -> PremiumScreen(padding)
                else -> ProfileScreen(padding)
            }
        }
    }
}

@Composable
fun HomeScreen(padding: PaddingValues, open: (String) -> Unit) {
    val tools = listOf(
        Tool("AI Script", "✍️", "Topic se script banao"),
        Tool("Title Generator", "🔥", "Clickable title ideas"),
        Tool("Hashtags", "#️⃣", "Niche hashtags"),
        Tool("Shorts Generator", "🎬", "15/30/60 sec ideas"),
        Tool("Thumbnail Ideas", "🖼️", "Thumbnail concepts"),
        Tool("SEO Helper", "📈", "Video SEO checklist"),
        Tool("Earnings", "💰", "YouTube earning calculator"),
        Tool("Content Planner", "📅", "Weekly content plan")
    )
    Column(
        Modifier.padding(padding).padding(16.dp).fillMaxSize()
    ) {
        Text("Creator Helper", fontSize = 30.sp, fontWeight = FontWeight.ExtraBold)
        Text("Chhota Step, Bada Growth! 🚀", color = Color.LightGray)
        Spacer(Modifier.height(18.dp))
        Card(
            colors = CardDefaults.cardColors(containerColor = Color(0xFF1B2438)),
            shape = RoundedCornerShape(20.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(Modifier.padding(18.dp)) {
                Text("Creator Tools", fontSize = 20.sp, fontWeight = FontWeight.Bold)
                Text("Apna topic choose karo aur creation fast karo.", color = Color.LightGray)
                Spacer(Modifier.height(10.dp))
                Button(onClick = { open("Templates") }) { Text("View Templates") }
            }
        }
        Spacer(Modifier.height(18.dp))
        Text("All Tools", fontSize = 20.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        LazyVerticalGrid(
            columns = GridCells.Fixed(2),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            items(tools) { tool ->
                Card(
                    onClick = { },
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF151D2E)),
                    shape = RoundedCornerShape(18.dp)
                ) {
                    Column(Modifier.padding(16.dp).height(115.dp), verticalArrangement = Arrangement.Center) {
                        Text(tool.emoji, fontSize = 28.sp)
                        Text(tool.title, fontWeight = FontWeight.Bold)
                        Text(tool.description, fontSize = 12.sp, color = Color.LightGray)
                    }
                }
            }
        }
    }
}

@Composable
fun TemplatesScreen(padding: PaddingValues) {
    val categories = listOf("🔥 Viral", "📰 News", "🏏 Cricket", "🎮 Gaming", "💪 Motivation", "🎬 Shorts", "💰 Finance", "✈️ Travel")
    Column(Modifier.padding(padding).padding(16.dp)) {
        Text("Premium Templates", fontSize = 28.sp, fontWeight = FontWeight.ExtraBold)
        Text("Original editable designs for creators.", color = Color.LightGray)
        Spacer(Modifier.height(16.dp))
        categories.forEach {
            Card(
                modifier = Modifier.fillMaxWidth().padding(vertical = 5.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF171F31)),
                shape = RoundedCornerShape(16.dp)
            ) {
                Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(it, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.weight(1f))
                    Text("OPEN", color = Color(0xFFFFC107), fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
fun PremiumScreen(padding: PaddingValues) {
    Column(
        Modifier.padding(padding).padding(20.dp).fillMaxSize(),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("⭐ Creator Helper Premium", fontSize = 27.sp, fontWeight = FontWeight.ExtraBold)
        Spacer(Modifier.height(15.dp))
        Text("Unlimited tools + premium template packs", color = Color.LightGray)
        Spacer(Modifier.height(25.dp))
        Text("₹99 / month", fontSize = 32.sp, fontWeight = FontWeight.Bold, color = Color(0xFFFFC107))
        Text("₹499 / year", fontSize = 20.sp)
        Spacer(Modifier.height(20.dp))
        Button(onClick = {}) { Text("Coming Soon") }
    }
}

@Composable
fun ProfileScreen(padding: PaddingValues) {
    Column(Modifier.padding(padding).padding(20.dp)) {
        Text("Profile", fontSize = 28.sp, fontWeight = FontWeight.ExtraBold)
        Spacer(Modifier.height(15.dp))
        Text("Creator Helper V1")
        Text("Login, settings and subscription will be added in the next version.", color = Color.LightGray)
    }
}
