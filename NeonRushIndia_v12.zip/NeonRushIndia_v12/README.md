# Neon Rush India v1.0.12

A lightweight Android endless runner made with Java only (no Kotlin dependencies).

Features:
- Premium neon India-style menu
- 3-lane endless runner
- Swipe left/right to change lane
- Swipe up to jump
- Cars, coins and power-ups
- Shield, Magnet and Boost power-ups
- Pause, restart and main menu
- Persistent high score and coins
- 3 skins
- Missions
- Android API 36 / Java 17

## GitHub
If you upload the ZIP as one file into GitHub, extract it before building, or upload the contents of this folder to the repository root. The included workflow expects the Android project files at repository root.
