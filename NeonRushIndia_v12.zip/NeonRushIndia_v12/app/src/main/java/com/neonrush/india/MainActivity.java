package com.neonrush.india;

import android.app.Activity;
import android.os.Bundle;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.*;
import android.view.*;
import java.util.*;

public class MainActivity extends Activity {
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        getWindow().getDecorView().setSystemUiVisibility(5894);
        setContentView(new GameView(this));
    }

    static class GameView extends View {
        enum Screen { MENU, GAME, OVER, SKINS, MISSIONS }
        enum Power { SHIELD, MAGNET, BOOST }
        static class Item { int lane, type; float y; Item(int l,float yy,int t){lane=l;y=yy;type=t;} }

        final Paint p = new Paint(3), text = new Paint(3), glow = new Paint(3);
        final SharedPreferences prefs;
        final Random rnd = new Random();
        final ArrayList<Item> cars = new ArrayList<>(), coinItems = new ArrayList<>(), powerItems = new ArrayList<>();
        final float[] skyline = new float[22];
        Screen screen = Screen.MENU;
        Power activePower = null;
        int lane=1, score=0, runCoins=0, best, totalCoins, skin;
        float speed=8f, scroll=0f, spawn=0f, powerSpawn=0f, jump=0f, powerLeft=0f, shake=0f;
        long last=0; float downX,downY;

        GameView(Context c) {
            super(c); setFocusable(true); prefs=c.getSharedPreferences("save",0);
            best=prefs.getInt("best",0); totalCoins=prefs.getInt("coins",0); skin=prefs.getInt("skin",0);
            for(int i=0;i<skyline.length;i++) skyline[i]=.2f+rnd.nextFloat()*.8f;
            text.setTypeface(Typeface.create(Typeface.DEFAULT,Typeface.BOLD));
        }
        int cyan=Color.rgb(0,225,255), purple=Color.rgb(165,70,255), pink=Color.rgb(255,65,120);
        float laneX(float w,int l){ float left=w*.12f,right=w*.88f; return left+(right-left)*(l+.5f)/3f; }

        @Override protected void onDraw(Canvas c){
            float w=getWidth(),h=getHeight(); background(c,w,h);
            if(screen==Screen.MENU) menu(c,w,h);
            else if(screen==Screen.GAME){ if(!paused) update(h); game(c,w,h); if(paused) pause(c,w,h); postInvalidateDelayed(16); }
            else if(screen==Screen.OVER){ game(c,w,h); overlayOver(c,w,h); }
            else if(screen==Screen.SKINS) skins(c,w,h);
            else missions(c,w,h);
        }
        boolean paused=false;

        void background(Canvas c,float w,float h){
            p.setShader(new LinearGradient(0,0,0,h,Color.rgb(5,7,25),Color.rgb(35,5,55),Shader.TileMode.CLAMP)); c.drawRect(0,0,w,h,p); p.setShader(null);
            p.setColor(Color.rgb(150,130,255)); c.drawCircle(w*.78f,h*.13f,w*.055f,p);
            float x=0;
            for(int i=0;i<skyline.length;i++){ float bw=w*.045f; float bh=h*(.12f+skyline[i]*.25f); p.setColor(Color.rgb(12,12,35)); c.drawRect(x,h*.55f-bh,x+bw,h*.55f,p); p.setColor(Color.rgb(75,45,135)); for(float yy=h*.55f-bh+18;yy<h*.55f-8;yy+=24)c.drawRect(x+6,yy,x+bw-6,yy+4,p); x+=bw+5; }
        }
        void road(Canvas c,float w,float h){
            float l=w*.12f,r=w*.88f; p.setColor(Color.rgb(10,10,25)); c.drawRect(l,0,r,h,p);
            glow.setStyle(Paint.Style.STROKE); glow.setStrokeWidth(7); glow.setColor(cyan); c.drawLine(l,0,l,h,glow); c.drawLine(r,0,r,h,glow); glow.setStyle(Paint.Style.FILL);
            p.setColor(Color.rgb(55,38,88)); float a=l+(r-l)/3,b=l+2*(r-l)/3; float y=-70+scroll;
            while(y<h){c.drawRoundRect(a-4,y,a+4,y+40,5,5,p);c.drawRoundRect(b-4,y,b+4,y+40,5,5,p);y+=78;}
        }
        void menu(Canvas c,float w,float h){
            text.setTextAlign(Paint.Align.CENTER); text.setColor(cyan); text.setTextSize(w*.115f); c.drawText("NEON RUSH",w/2,h*.17f,text);
            text.setColor(Color.WHITE); text.setTextSize(w*.06f); c.drawText("INDIA",w/2,h*.235f,text);
            text.setColor(Color.rgb(190,175,220)); text.setTextSize(w*.028f); c.drawText("RUN • DODGE • COLLECT • SURVIVE",w/2,h*.285f,text);
            drawPlayer(c,w/2,h*.40f,w*.09f,false);
            button(c,w*.17f,h*.50f,w*.83f,h*.60f,"PLAY NOW",true);
            button(c,w*.17f,h*.625f,w*.47f,h*.70f,"SKINS",false); button(c,w*.53f,h*.625f,w*.83f,h*.70f,"MISSIONS",false);
            text.setTextSize(w*.028f); text.setColor(Color.LTGRAY); c.drawText("BEST  "+best+"    •    COINS  "+totalCoins,w/2,h*.78f,text);
            text.setTextSize(w*.024f); c.drawText("Swipe ← → lane   •   Swipe ↑ jump",w/2,h*.86f,text);
            text.setColor(Color.rgb(120,100,160)); c.drawText("NEON RUSH INDIA  •  v1.0.12",w/2,h*.93f,text);
        }
        void button(Canvas c,float l,float t,float r,float b,String s,boolean primary){
            p.setColor(primary?Color.rgb(0,125,190):Color.rgb(30,23,55)); c.drawRoundRect(l,t,r,b,24,24,p);
            glow.setStyle(Paint.Style.STROKE); glow.setStrokeWidth(3); glow.setColor(primary?cyan:purple); c.drawRoundRect(l,t,r,b,24,24,glow); glow.setStyle(Paint.Style.FILL);
            text.setTextAlign(Paint.Align.CENTER); text.setTextSize((b-t)*.38f); text.setColor(Color.WHITE); c.drawText(s,(l+r)/2,t+(b-t)*.64f,text);
        }
        void start(){screen=Screen.GAME;paused=false;lane=1;score=runCoins=0;speed=8;scroll=spawn=powerSpawn=jump=powerLeft=shake=0;activePower=null;cars.clear();coinItems.clear();powerItems.clear();last=0;invalidate();}
        void update(float h){
            long now=System.currentTimeMillis(); if(last==0)last=now; float dt=Math.max(.5f,Math.min(2.4f,(now-last)/16f)); last=now;
            speed=Math.min(18.5f,speed+.0025f*dt); score+=Math.max(1,(int)(speed/8)); scroll=(scroll+speed*dt)%78;
            spawn+=dt; powerSpawn+=dt;
            if(spawn>Math.max(20,50-speed*1.5f)){spawn=0; int l=rnd.nextInt(3); int roll=rnd.nextInt(100); if(roll<62)cars.add(new Item(l,-80,0)); else coinItems.add(new Item(l,-60,0)); if(rnd.nextInt(100)<22)cars.add(new Item((l+1+rnd.nextInt(2))%3,-150,0));}
            if(powerSpawn>150){powerSpawn=0;powerItems.add(new Item(rnd.nextInt(3),-80,rnd.nextInt(3)));}
            for(Item i:cars)i.y+=speed*dt; for(Item i:coinItems)i.y+=speed*dt; for(Item i:powerItems)i.y+=speed*dt;
            removeOff(cars,h);removeOff(coinItems,h);removeOff(powerItems,h);
            if(jump>0)jump=Math.max(0,jump-.055f*dt); if(activePower!=null){powerLeft-=dt;if(powerLeft<=0)activePower=null;}
            float py=h*.77f-jump*h*.19f;
            Item hit=null; for(Item i:cars)if(i.lane==lane && Math.abs(i.y-h*.77f)<55 && jump<.25){hit=i;break;}
            if(hit!=null){if(activePower==Power.SHIELD){cars.remove(hit);activePower=null;shake=12;}else{end();return;}}
            Item co=null; for(Item i:coinItems){boolean near=i.lane==lane || (activePower==Power.MAGNET&&Math.abs(i.lane-lane)<=1);if(near&&Math.abs(i.y-py)<(activePower==Power.MAGNET?130:55)){co=i;break;}}
            if(co!=null){coinItems.remove(co);runCoins++;totalCoins++;score+=(runCoins%10==0?100:0);}
            Item po=null; for(Item i:powerItems)if(i.lane==lane&&Math.abs(i.y-py)<65){po=i;break;}
            if(po!=null){powerItems.remove(po);activePower=Power.values()[po.type];powerLeft=240;score+=50;}
            if(shake>0)shake-=dt;
        }
        void removeOff(ArrayList<Item> list,float h){for(int i=list.size()-1;i>=0;i--)if(list.get(i).y>h+100)list.remove(i);}
        void end(){best=Math.max(best,score);prefs.edit().putInt("best",best).putInt("coins",totalCoins).putInt("skin",skin).apply();screen=Screen.OVER;paused=false;}
        void game(Canvas c,float w,float h){
            c.save(); if(shake>0)c.translate((rnd.nextFloat()-.5f)*shake,(rnd.nextFloat()-.5f)*shake); road(c,w,h);
            for(Item i:cars)car(c,laneX(w,i.lane),i.y,w*.065f); for(Item i:coinItems)coin(c,laneX(w,i.lane),i.y,w*.024f); for(Item i:powerItems)power(c,laneX(w,i.lane),i.y,w*.032f,Power.values()[i.type]);
            drawPlayer(c,laneX(w,lane),h*.77f-jump*h*.19f,w*.075f,jump>0); c.restore(); hud(c,w,h);
        }
        void car(Canvas c,float x,float y,float s){p.setColor(pink);c.drawRoundRect(x-s,y-s*.6f,x+s,y+s*.6f,s*.3f,s*.3f,p);p.setColor(Color.rgb(30,35,60));c.drawRoundRect(x-s*.55f,y-s*.43f,x+s*.55f,y,s*.2f,s*.2f,p);p.setColor(Color.WHITE);c.drawCircle(x-s*.58f,y+s*.38f,s*.14f,p);c.drawCircle(x+s*.58f,y+s*.38f,s*.14f,p);p.setColor(Color.YELLOW);c.drawCircle(x-s*.75f,y-s*.12f,s*.08f,p);c.drawCircle(x+s*.75f,y-s*.12f,s*.08f,p);}
        void coin(Canvas c,float x,float y,float r){p.setColor(Color.rgb(255,200,30));c.drawCircle(x,y,r*1.35f,p);p.setColor(Color.rgb(255,240,110));c.drawCircle(x,y,r,p);text.setTextAlign(Paint.Align.CENTER);text.setTextSize(r*1.1f);text.setColor(Color.rgb(120,70,0));c.drawText("₹",x,y+r*.35f,text);}
        void power(Canvas c,float x,float y,float r,Power q){int col=q==Power.SHIELD?cyan:q==Power.MAGNET?purple:Color.rgb(255,145,20);p.setColor(col);c.drawCircle(x,y,r*1.5f,p);text.setTextAlign(Paint.Align.CENTER);text.setTextSize(r);text.setColor(Color.WHITE);c.drawText(q==Power.SHIELD?"S":q==Power.MAGNET?"M":"B",x,y+r*.35f,text);}
        void drawPlayer(Canvas c,float x,float y,float s,boolean air){int body=skin==1?Color.rgb(255,80,125):skin==2?purple:cyan;glow.setColor(body);glow.setShadowLayer(16,0,0,body);c.drawCircle(x,y-s*.35f,s*.5f,glow);glow.clearShadowLayer();p.setColor(body);c.drawRoundRect(x-s*.45f,y-s*.9f,x+s*.45f,y+s*.15f,s*.25f,s*.25f,p);p.setColor(Color.WHITE);c.drawCircle(x-s*.16f,y-s*.56f,s*.09f,p);c.drawCircle(x+s*.16f,y-s*.56f,s*.09f,p);p.setColor(Color.DKGRAY);c.drawCircle(x-s*.16f,y-s*.56f,s*.04f,p);c.drawCircle(x+s*.16f,y-s*.56f,s*.04f,p);p.setColor(Color.rgb(30,30,55));float a=air?s*.15f:0;c.drawRoundRect(x-s*.33f,y+s*.08f,x-s*.10f,y+s*.5f+a,s*.1f,s*.1f,p);c.drawRoundRect(x+s*.10f,y+s*.08f,x+s*.33f,y+s*.5f-a,s*.1f,s*.1f,p);}
        void hud(Canvas c,float w,float h){p.setColor(Color.argb(190,10,8,30));c.drawRoundRect(15,15,w*.43f,68,18,18,p);c.drawRoundRect(w*.57f,15,w-15,68,18,18,p);text.setTextAlign(Paint.Align.LEFT);text.setTextSize(w*.035f);text.setColor(Color.WHITE);c.drawText("SCORE  "+score,28,49,text);text.setTextAlign(Paint.Align.RIGHT);c.drawText("COINS  "+runCoins,w-28,49,text);p.setColor(Color.rgb(38,30,65));c.drawRoundRect(w*.43f,80,w*.57f,130,15,15,p);text.setTextAlign(Paint.Align.CENTER);text.setTextSize(22);c.drawText("Ⅱ",w*.5f,114,text);if(activePower!=null){float f=Math.max(0,Math.min(1,powerLeft/240));p.setColor(Color.argb(180,15,15,40));c.drawRoundRect(w*.22f,h*.10f,w*.78f,h*.145f,16,16,p);p.setColor(activePower==Power.SHIELD?cyan:activePower==Power.MAGNET?purple:Color.rgb(255,145,20));c.drawRoundRect(w*.22f,h*.10f,w*.22f+w*.56f*f,h*.145f,16,16,p);text.setTextSize(w*.025f);text.setColor(Color.WHITE);c.drawText(activePower==Power.SHIELD?"SHIELD":activePower==Power.MAGNET?"MAGNET":"BOOST",w*.5f,h*.132f,text);}}
        void overlayOver(Canvas c,float w,float h){p.setColor(Color.argb(220,2,2,10));c.drawRect(0,0,w,h,p);text.setTextAlign(Paint.Align.CENTER);text.setTextSize(w*.085f);text.setColor(pink);c.drawText("RUN OVER",w/2,h*.30f,text);text.setTextSize(w*.043f);text.setColor(Color.WHITE);c.drawText("SCORE  "+score,w/2,h*.39f,text);c.drawText("BEST   "+best,w/2,h*.45f,text);c.drawText("COINS  "+runCoins,w/2,h*.51f,text);button(c,w*.18f,h*.59f,w*.82f,h*.68f,"RUN AGAIN",true);button(c,w*.18f,h*.71f,w*.82f,h*.79f,"MAIN MENU",false);}
        void pause(Canvas c,float w,float h){p.setColor(Color.argb(215,0,0,10));c.drawRect(0,0,w,h,p);text.setTextAlign(Paint.Align.CENTER);text.setTextSize(w*.09f);text.setColor(Color.WHITE);c.drawText("PAUSED",w/2,h*.39f,text);button(c,w*.23f,h*.49f,w*.77f,h*.58f,"RESUME",true);button(c,w*.23f,h*.62f,w*.77f,h*.71f,"MENU",false);}
        void skins(Canvas c,float w,float h){text.setTextAlign(Paint.Align.CENTER);text.setTextSize(w*.075f);text.setColor(Color.WHITE);c.drawText("SKINS",w/2,h*.13f,text);String[] n={"CYAN RUNNER","PINK FLASH","PURPLE PRO"};for(int i=0;i<3;i++){float y=h*(.29f+i*.22f);p.setColor(skin==i?Color.rgb(25,65,85):Color.rgb(25,20,48));c.drawRoundRect(w*.12f,y-h*.065f,w*.88f,y+h*.065f,22,22,p);int old=skin;skin=i;drawPlayer(c,w*.28f,y,w*.055f,false);skin=old;text.setTextAlign(Paint.Align.LEFT);text.setTextSize(w*.032f);text.setColor(Color.WHITE);c.drawText(n[i],w*.40f,y-4,text);text.setTextSize(w*.024f);text.setColor(skin==i?cyan:Color.LTGRAY);c.drawText(skin==i?"EQUIPPED":"TAP TO EQUIP",w*.40f,y+28,text);}button(c,w*.22f,h*.87f,w*.78f,h*.94f,"BACK",false);}
        void missions(Canvas c,float w,float h){text.setTextAlign(Paint.Align.CENTER);text.setTextSize(w*.075f);text.setColor(Color.WHITE);c.drawText("MISSIONS",w/2,h*.13f,text);mission(c,w,h,.28f,"FIRST RUN",score>0);mission(c,w,h,.46f,"COIN HUNTER",totalCoins>=10);mission(c,w,h,.64f,"HIGH FLYER",best>=500);mission(c,w,h,.82f,"ROAD LEGEND",best>=1000);button(c,w*.22f,h*.89f,w*.78f,h*.96f,"BACK",false);}
        void mission(Canvas c,float w,float h,float yy,String s,boolean done){float y=h*yy;p.setColor(done?Color.rgb(20,70,65):Color.rgb(25,20,48));c.drawRoundRect(w*.12f,y-h*.05f,w*.88f,y+h*.05f,18,18,p);text.setTextAlign(Paint.Align.LEFT);text.setTextSize(w*.032f);text.setColor(Color.WHITE);c.drawText(s,w*.20f,y-2,text);text.setTextSize(w*.023f);text.setColor(done?cyan:Color.LTGRAY);c.drawText(done?"COMPLETED":"KEEP RUNNING",w*.20f,y+25,text);text.setTextAlign(Paint.Align.RIGHT);text.setTextSize(w*.045f);c.drawText(done?"✓":"•",w*.80f,y+10,text);}
        @Override public boolean onTouchEvent(MotionEvent e){if(e.getAction()==MotionEvent.ACTION_DOWN){downX=e.getX();downY=e.getY();return true;}if(e.getAction()!=MotionEvent.ACTION_UP)return true;float x=e.getX(),y=e.getY(),w=getWidth(),h=getHeight(),dx=x-downX,dy=y-downY;
            if(screen==Screen.MENU){if(y>h*.48&&y<h*.62)start();else if(y>h*.61&&y<h*.73&&x<w*.5){screen=Screen.SKINS;}else if(y>h*.61&&y<h*.73){screen=Screen.MISSIONS;}}
            else if(screen==Screen.GAME){if(paused){if(y>h*.47&&y<h*.61)paused=false;else if(y>h*.60&&y<h*.76){screen=Screen.MENU;paused=false;}}else if(y<145&&x>w*.40&&x<w*.60)paused=true;else if(Math.abs(dx)>Math.abs(dy)&&Math.abs(dx)>45)lane=Math.max(0,Math.min(2,lane+(dx>0?1:-1)));else if(dy<-45&&jump<=0)jump=1;}
            else if(screen==Screen.OVER){if(y>h*.56&&y<h*.70)start();else if(y>h*.70&&y<h*.84)screen=Screen.MENU;}
            else if(screen==Screen.SKINS){if(y>h*.20&&y<h*.38)skin=0;else if(y>=h*.38&&y<h*.60)skin=1;else if(y>=h*.60&&y<h*.84)skin=2;else if(y>h*.84)screen=Screen.MENU;prefs.edit().putInt("skin",skin).apply();}
            else if(screen==Screen.MISSIONS){if(y>h*.84)screen=Screen.MENU;}
            invalidate();return true;
        }
    }
}
